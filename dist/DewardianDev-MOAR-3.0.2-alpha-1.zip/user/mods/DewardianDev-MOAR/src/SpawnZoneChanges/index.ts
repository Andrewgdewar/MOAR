// context/index.js
export { default as PlayerSpawns } from "../../config/Spawns/playerSpawns.json";
export { default as ScavSpawns } from "../../config/Spawns/scavSpawns.json";
export { default as SniperSpawns } from "../../config/Spawns/sniperSpawns.json";
export { default as PmcSpawns } from "../../config/Spawns/pmcSpawns.json";
